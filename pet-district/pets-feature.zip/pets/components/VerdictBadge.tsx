/**
 * SAFE · LIMIT · AVOID.
 *
 * Three answers and three inks, taken from the city's existing status tokens
 * rather than a new green, amber and red invented for this hub. A fourth state
 * is not available on purpose: "it depends" is what the reason line is for.
 */

import type { Verdict } from '../types';

const TONE: Record<Verdict, { ink: string; soft: string; line: string; word: string }> = {
  SAFE: { ink: 'var(--ok-ink)', soft: 'var(--ok-soft)', line: 'var(--ok-line)', word: 'Generally appropriate in suitable portions' },
  LIMIT: { ink: 'var(--warn-ink)', soft: 'var(--warn-soft)', line: 'var(--warn-line)', word: 'Only in moderation, prepared correctly' },
  AVOID: { ink: 'var(--danger-ink)', soft: 'var(--danger-soft)', line: 'var(--danger-line)', word: 'Not recommended' },
};

export function VerdictBadge({ verdict, size = 'md' }: { verdict: Verdict; size?: 'sm' | 'md' | 'lg' }) {
  const t = TONE[verdict];
  const pad = size === 'lg' ? '10px 18px' : size === 'sm' ? '3px 9px' : '6px 13px';
  const font = size === 'lg' ? 18 : size === 'sm' ? 10 : 12;
  return (
    <span
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 8, padding: pad, borderRadius: 999,
        background: t.soft, color: t.ink, border: `1px solid ${t.line}`,
        fontSize: font, fontWeight: 800, letterSpacing: '.08em', textTransform: 'uppercase',
      }}
    >
      {verdict}
    </span>
  );
}

export const verdictLine = (v: Verdict) => TONE[v].word;
export const verdictInk = (v: Verdict) => TONE[v].ink;

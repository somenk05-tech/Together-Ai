/**
 * THE SHELF TILE.
 *
 * Four things you compare across a grid — picture, brand, name, price — and
 * everything else one tap down, which is the same argument the Beauty market
 * settled one hub over. Two additions this hub needs and that one does not:
 *
 * · A VET-GUIDANCE MARK. Prescription diets and parasiticides are in this
 *   catalogue because pet parents need to find them. They must never look like
 *   an ordinary add-to-cart, so they carry the mark on the tile, not on the
 *   product page where the decision has already been made.
 *
 * · AN UNVERIFIED-PRICE STATE. See PriceLine — twelve rows have no confirmed
 *   price and the tile says so rather than hiding them.
 *
 * THE PICTURE IS A DRAWN CASE, NOT THE RETAILER'S PHOTOGRAPH. The catalogue
 * holds the source image URL for research, and republishing it is a licensing
 * question nobody has answered yet, so the shelf draws a pack shape tinted by
 * category. When the merchant deal is signed this is a one-line change.
 */

import type { Product } from '../types';
import { PriceLine } from './PriceLine';
import { shortName } from '../engine/naming';

/**
 * THE PACK, DRAWN.
 *
 * An emoji here was the first thing that read as a children's app rather than a
 * premium shop — colour picked by the platform, sized by the font, different on
 * every device. These are four flat silhouettes in the city's own ink: a bag, a
 * tin, a bottle and a soft shape for everything else.
 */
type PackShape = 'bag' | 'tin' | 'bottle' | 'soft';

const SHAPE: Record<string, PackShape> = {
  food: 'bag', 'vet-diet': 'bag', litter: 'bag', treats: 'bag',
  home: 'tin', toys: 'soft', walk: 'soft', fashion: 'soft',
  grooming: 'bottle', wellness: 'bottle', cleaning: 'bottle', training: 'tin',
};

function PackShot({ shape, size = 74 }: { shape: PackShape; size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" aria-hidden fill="none">
      <g stroke="var(--ink-soft)" strokeWidth="1.6" strokeLinejoin="round" opacity="0.85">
        {shape === 'bag' && (
          <>
            <path d="M18 20h28l3 32a4 4 0 0 1-4 4H19a4 4 0 0 1-4-4l3-32Z" fill="var(--card)" />
            <path d="M22 20c0-5 4-8 10-8s10 3 10 8" />
            <path d="M23 30h18M23 38h12" opacity="0.45" />
          </>
        )}
        {shape === 'tin' && (
          <>
            <ellipse cx="32" cy="20" rx="15" ry="5" fill="var(--card)" />
            <path d="M17 20v22c0 3 7 5 15 5s15-2 15-5V20" fill="var(--card)" />
            <path d="M17 42c0 3 7 5 15 5s15-2 15-5" />
          </>
        )}
        {shape === 'bottle' && (
          <>
            <path d="M28 12h8v7c0 2 6 4 6 10v20a5 5 0 0 1-5 5H27a5 5 0 0 1-5-5V29c0-6 6-8 6-10v-7Z" fill="var(--card)" />
            <path d="M26 32h12" opacity="0.45" />
          </>
        )}
        {shape === 'soft' && (
          <>
            <path d="M32 14c11 0 18 8 18 19s-7 19-18 19-18-8-18-19 7-19 18-19Z" fill="var(--card)" />
            <path d="M24 30c3-4 13-4 16 0" opacity="0.45" />
          </>
        )}
      </g>
    </svg>
  );
}

interface Props {
  product: Product;
  onOpen: () => void;
  onAdd: () => void;
  onWishlist: () => void;
  onCompare: () => void;
  wishlisted: boolean;
  comparing: boolean;
  inCart: number;
  reason?: string | null;
}

export function ProductTile(
  { product, onOpen, onAdd, onWishlist, onCompare, wishlisted, comparing, inCart, reason }: Props,
) {
  return (
    <article
      className="card"
      style={{ display: 'flex', flexDirection: 'column', gap: 10, padding: 14, position: 'relative', minWidth: 0 }}
    >
      <button
        type="button"
        onClick={onWishlist}
        aria-label={wishlisted ? `Remove ${product.name} from wishlist` : `Save ${product.name} to wishlist`}
        aria-pressed={wishlisted}
        style={{
          position: 'absolute', top: 8, right: 8, width: 34, height: 34, borderRadius: '50%',
          border: 'none', background: 'transparent', cursor: 'pointer', fontSize: 15, lineHeight: 1,
          color: wishlisted ? 'var(--danger-ink)' : 'var(--muted)',
        }}
      >
        {wishlisted ? '♥' : '♡'}
      </button>

      <button
        type="button"
        onClick={onOpen}
        style={{
          border: 'none', background: 'var(--wash)', borderRadius: 'var(--r-2)', cursor: 'pointer',
          padding: '18px 12px', display: 'grid', placeItems: 'center', gap: 4, minHeight: 132,
        }}
      >
        <PackShot shape={SHAPE[product.category] ?? 'soft'} />
        <span className="muted" style={{ fontSize: 10, letterSpacing: '.1em', textTransform: 'uppercase' }}>
          {product.subcategory || product.category}
        </span>
      </button>

      <div style={{ display: 'grid', gap: 3, minWidth: 0 }}>
        <span className="muted" style={{ fontSize: 10, fontWeight: 800, letterSpacing: '.1em', textTransform: 'uppercase' }}>
          {product.brand}
        </span>
        <button
          type="button"
          onClick={onOpen}
          style={{ border: 'none', background: 'none', padding: 0, textAlign: 'left', font: 'inherit', fontSize: 13.5, fontWeight: 600, lineHeight: 1.35, cursor: 'pointer' }}
        >
          {shortName(product)}
        </button>
        <span className="muted" style={{ fontSize: 11.5 }}>
          {product.packSizes[0] ?? 'Pack size not stated'}
          {product.lifeStage !== 'all' ? ` · ${product.lifeStage}` : ''}
        </span>
      </div>

      <PriceLine product={product} />

      {product.vetGuidance && (
        <p style={{ margin: 0, fontSize: 11, lineHeight: 1.45, color: 'var(--warn-ink)', background: 'var(--warn-soft)', border: '1px solid var(--warn-line)', borderRadius: 'var(--r-1)', padding: '6px 9px' }}>
          Vet guidance required before use
        </p>
      )}

      {reason && (
        <p className="muted" style={{ margin: 0, fontSize: 11.5, lineHeight: 1.5 }}>
          <strong style={{ color: 'var(--accent-ink)' }}>Why this: </strong>{reason}
        </p>
      )}

      <div style={{ display: 'flex', gap: 6, marginTop: 'auto', paddingTop: 4 }}>
        <button
          type="button"
          onClick={onAdd}
          className="btn btn-sm"
          style={{ flex: 1, background: inCart ? 'var(--ok-soft)' : 'var(--accent)', color: inCart ? 'var(--ok-ink)' : 'var(--on-accent)', border: 'none' }}
        >
          {inCart ? `In cart · ${inCart}` : 'Add to cart'}
        </button>
        <button
          type="button"
          onClick={onCompare}
          aria-pressed={comparing}
          className="btn btn-sm btn-line"
          style={{ paddingInline: 10, color: comparing ? 'var(--accent-ink)' : 'var(--ink-soft)' }}
        >
          {comparing ? '✓ Compare' : 'Compare'}
        </button>
      </div>
    </article>
  );
}

/**
 * TWO PETS THE HUB CAN BE READ WITH.
 *
 * The empty state is the honest first screen and it is the one a new citizen
 * sees. These exist so that everything downstream — the planner, the weekly
 * grid, the scorecard, the shop's "recommended for" rail — can be looked at
 * without filling a form first, and so a reviewer can see what the product does
 * before deciding whether to use it.
 *
 * They are a Labrador and an Indian domestic shorthair on purpose: the most
 * common pedigree dog in urban India and the most common cat in the country.
 */

import type { Pet } from '../types';

export const SAMPLE_PETS: Pet[] = [
  {
    id: 'pet-max',
    name: 'Max',
    species: 'dog',
    breed: 'Labrador Retriever',
    dob: '2022-04-12',
    ageMonths: null,
    sex: 'male',
    weightKg: 31,
    targetWeightKg: 28,
    bodyCondition: 'over',
    activity: 'moderate',
    housing: 'both',
    sterilised: true,
    allergies: ['Chicken'],
    sensitivities: ['Rich or oily food'],
    restrictions: [],
    currentFood: 'Drools Focus Adult, 3 kg pack',
    dietStyle: 'mixed',
    goal: 'weight-loss',
    healthNotes: 'Slightly stiff after long walks in the monsoon.',
    portrait: 'labrador',
    createdAt: '2026-01-08',
  },
  {
    id: 'pet-mishti',
    name: 'Mishti',
    species: 'cat',
    breed: 'Indian Billi / Domestic Shorthair',
    dob: '2024-09-02',
    ageMonths: null,
    sex: 'female',
    weightKg: 3.8,
    targetWeightKg: 3.8,
    bodyCondition: 'ideal',
    activity: 'high',
    housing: 'indoor',
    sterilised: true,
    allergies: [],
    sensitivities: [],
    restrictions: [],
    currentFood: 'Whiskas Ocean Fish Adult, 1.2 kg',
    dietStyle: 'commercial',
    goal: 'maintain',
    healthNotes: '',
    portrait: 'shorthair',
    createdAt: '2026-02-19',
  },
];

/**
 * ── THE HUB'S STATE, IN ONE STORE ───────────────────────────────────────────
 *
 * Zustand, matching the rest of the application, and deliberately IN MEMORY.
 * Nothing here writes to localStorage: a pet profile is the citizen's record
 * and belongs on the server behind their account, not in a browser store that
 * one device knows about and the next does not. `api.ts` is the seam where the
 * NestJS endpoints replace these actions; the shape of every action is already
 * the shape of the call that will replace it.
 *
 * WHAT THIS MEANS TODAY: a reload starts the demo again with the two sample
 * pets. That is a truthful prototype rather than a hidden dependency on a
 * storage layer nobody signed off.
 */

import { create } from 'zustand';
import type {
  ActivityEntry, CartLine, DayPlan, NutritionPlan, Pet, ShoppingItem,
  SubscriptionCadence, WellnessEntry,
} from './types';
import { SAMPLE_PETS } from './data/samplePets';
import { buildPlan, regenerateMeal } from './engine/plan';
import { shoppingFor } from './engine/shopping';

export interface PetsState {
  pets: Pet[];
  activePetId: string | null;
  plans: Record<string, NutritionPlan>;
  favourites: string[];
  cart: CartLine[];
  wishlist: string[];
  compare: string[];
  subscriptions: { productId: string; cadence: SubscriptionCadence }[];
  shopping: ShoppingItem[];
  wellness: WellnessEntry[];
  activity: ActivityEntry[];
  loading: boolean;
  error: string | null;

  loadSamples: () => void;
  clearAll: () => void;
  addPet: (pet: Pet) => void;
  updatePet: (id: string, patch: Partial<Pet>) => void;
  removePet: (id: string) => void;
  setActive: (id: string) => void;

  generatePlan: (petId: string) => void;
  setDay: (petId: string, day: DayPlan) => void;
  toggleMealDone: (petId: string, date: string, mealId: string) => void;
  regenerate: (petId: string, date: string, mealId: string) => void;
  toggleFavourite: (id: string) => void;

  buildShopping: (petId: string) => void;
  toggleShopping: (id: string) => void;
  addShoppingItem: (label: string, qty: string) => void;
  setShoppingQty: (id: string, qty: string) => void;

  addToCart: (productId: string, variantIndex: number, subscription?: SubscriptionCadence | null) => void;
  setCartQty: (productId: string, variantIndex: number, qty: number) => void;
  clearCart: () => void;
  toggleWishlist: (id: string) => void;
  toggleCompare: (id: string) => void;
  subscribe: (productId: string, cadence: SubscriptionCadence) => void;
  unsubscribe: (productId: string) => void;

  addWellness: (entry: WellnessEntry) => void;
  toggleWellness: (id: string) => void;
  addActivity: (entry: ActivityEntry) => void;

  setError: (message: string | null) => void;
  setLoading: (on: boolean) => void;
}

const uid = (prefix: string) => `${prefix}-${Math.random().toString(36).slice(2, 9)}`;

export const usePets = create<PetsState>((set, get) => ({
  pets: [],
  activePetId: null,
  plans: {},
  favourites: [],
  cart: [],
  wishlist: [],
  compare: [],
  subscriptions: [],
  shopping: [],
  wellness: [],
  activity: [],
  loading: false,
  error: null,

  loadSamples: () => {
    const pets = SAMPLE_PETS;
    const plans: Record<string, NutritionPlan> = {};
    pets.forEach((p) => { plans[p.id] = buildPlan(p); });
    const today = new Date().toISOString().slice(0, 10);
    set({
      pets,
      activePetId: pets[0].id,
      plans,
      shopping: shoppingFor(pets[0], plans[pets[0].id]),
      wellness: [
        { id: uid('w'), petId: 'pet-max', kind: 'vaccination', date: '2026-09-14', label: 'Annual booster', value: 'Due', done: false },
        { id: uid('w'), petId: 'pet-max', kind: 'parasite', date: '2026-08-25', label: 'Tick & flea treatment', value: 'Monthly', done: false },
        { id: uid('w'), petId: 'pet-max', kind: 'weight', date: today, label: 'Weigh-in', value: '31.0 kg', done: true },
        { id: uid('w'), petId: 'pet-max', kind: 'grooming', date: '2026-08-30', label: 'Bath and de-shed', value: 'Booked', done: false },
        { id: uid('w'), petId: 'pet-mishti', kind: 'vaccination', date: '2026-10-02', label: 'Annual booster', value: 'Due', done: false },
        { id: uid('w'), petId: 'pet-mishti', kind: 'dental', date: '2026-09-01', label: 'Dental check', value: 'Not booked', done: false },
      ],
      activity: [
        { id: uid('a'), petId: 'pet-max', date: today, kind: 'walk', minutes: 35 },
        { id: uid('a'), petId: 'pet-max', date: today, kind: 'play', minutes: 15 },
        { id: uid('a'), petId: 'pet-mishti', date: today, kind: 'play', minutes: 22 },
      ],
    });
  },

  clearAll: () => set({
    pets: [], activePetId: null, plans: {}, shopping: [], cart: [], wishlist: [],
    compare: [], subscriptions: [], wellness: [], activity: [], favourites: [],
  }),

  addPet: (pet) => set((s) => ({ pets: [...s.pets, pet], activePetId: pet.id })),
  updatePet: (id, patch) => set((s) => ({ pets: s.pets.map((p) => (p.id === id ? { ...p, ...patch } : p)) })),
  removePet: (id) => set((s) => {
    const pets = s.pets.filter((p) => p.id !== id);
    const { [id]: _removed, ...plans } = s.plans;
    return { pets, plans, activePetId: s.activePetId === id ? pets[0]?.id ?? null : s.activePetId };
  }),
  setActive: (id) => set({ activePetId: id }),

  generatePlan: (petId) => {
    const pet = get().pets.find((p) => p.id === petId);
    if (!pet) return;
    set((s) => ({ plans: { ...s.plans, [petId]: buildPlan(pet) } }));
  },

  setDay: (petId, day) => set((s) => {
    const plan = s.plans[petId];
    if (!plan) return {};
    return { plans: { ...s.plans, [petId]: { ...plan, days: plan.days.map((d) => (d.date === day.date ? day : d)) } } };
  }),

  toggleMealDone: (petId, date, mealId) => set((s) => {
    const plan = s.plans[petId];
    if (!plan) return {};
    return {
      plans: {
        ...s.plans,
        [petId]: {
          ...plan,
          days: plan.days.map((d) => d.date !== date ? d : {
            ...d, meals: d.meals.map((m) => (m.id === mealId ? { ...m, done: !m.done } : m)),
          }),
        },
      },
    };
  }),

  regenerate: (petId, date, mealId) => {
    const { pets, plans } = get();
    const pet = pets.find((p) => p.id === petId);
    const plan = plans[petId];
    const day = plan?.days.find((d) => d.date === date);
    if (!pet || !plan || !day) return;
    const next = regenerateMeal(pet, day, mealId, Date.now() % 997);
    get().setDay(petId, next);
  },

  toggleFavourite: (id) => set((s) => ({
    favourites: s.favourites.includes(id) ? s.favourites.filter((f) => f !== id) : [...s.favourites, id],
  })),

  buildShopping: (petId) => {
    const { pets, plans } = get();
    const pet = pets.find((p) => p.id === petId);
    const plan = plans[petId];
    if (!pet || !plan) return;
    set({ shopping: shoppingFor(pet, plan) });
  },
  toggleShopping: (id) => set((s) => ({
    shopping: s.shopping.map((i) => (i.id === id ? { ...i, checked: !i.checked } : i)),
  })),
  addShoppingItem: (label, qty) => set((s) => ({
    shopping: [...s.shopping, { id: uid('custom'), label, qty, source: 'home-kitchen', productId: null, checked: false, custom: true }],
  })),
  setShoppingQty: (id, qty) => set((s) => ({
    shopping: s.shopping.map((i) => (i.id === id ? { ...i, qty } : i)),
  })),

  addToCart: (productId, variantIndex, subscription = null) => set((s) => {
    const found = s.cart.find((l) => l.productId === productId && l.variantIndex === variantIndex);
    return found
      ? { cart: s.cart.map((l) => (l === found ? { ...l, qty: l.qty + 1, subscription: subscription ?? l.subscription } : l)) }
      : { cart: [...s.cart, { productId, variantIndex, qty: 1, subscription }] };
  }),
  setCartQty: (productId, variantIndex, qty) => set((s) => ({
    cart: qty <= 0
      ? s.cart.filter((l) => !(l.productId === productId && l.variantIndex === variantIndex))
      : s.cart.map((l) => (l.productId === productId && l.variantIndex === variantIndex ? { ...l, qty } : l)),
  })),
  clearCart: () => set({ cart: [] }),

  toggleWishlist: (id) => set((s) => ({
    wishlist: s.wishlist.includes(id) ? s.wishlist.filter((w) => w !== id) : [...s.wishlist, id],
  })),
  toggleCompare: (id) => set((s) => ({
    compare: s.compare.includes(id)
      ? s.compare.filter((c) => c !== id)
      : s.compare.length >= 3 ? [...s.compare.slice(1), id] : [...s.compare, id],
  })),
  subscribe: (productId, cadence) => set((s) => ({
    subscriptions: [...s.subscriptions.filter((x) => x.productId !== productId), { productId, cadence }],
  })),
  unsubscribe: (productId) => set((s) => ({ subscriptions: s.subscriptions.filter((x) => x.productId !== productId) })),

  addWellness: (entry) => set((s) => ({ wellness: [...s.wellness, entry] })),
  toggleWellness: (id) => set((s) => ({
    wellness: s.wellness.map((w) => (w.id === id ? { ...w, done: !w.done } : w)),
  })),
  addActivity: (entry) => set((s) => ({ activity: [...s.activity, entry] })),

  setError: (message) => set({ error: message }),
  setLoading: (on) => set({ loading: on }),
}));

export const newPetId = () => uid('pet');
export const newEntryId = (p: string) => uid(p);
